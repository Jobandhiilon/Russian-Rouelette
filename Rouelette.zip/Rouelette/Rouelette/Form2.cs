﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rouelette
{
    public partial class russian : Form
    { // these are the variables
        public int load, Spin,Score=0, Win=0, Loss =0, Count = 0 ;

        public russian()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {// below code helps to show the picbox
            picbox.Visible = true;
            //below code is for uploading the image
            Image img = Image.FromFile(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\shots.gif");
            picbox.Image = img;
            // below code is for uploading the sound
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\gun.wav");
            player.Play();
            if (Count < 2)
            {
                if (Spin == load)
                {
                    Win = Win + 1;
                    Score = Score + 10;
                    Spin = Spin + 1;
                    Count = 3;
                }
                else
                {
                    if (Spin == 6)
                    {
                        Spin = 1;
                    }
                    else
                    {
                        Spin = Spin + 1;
                    }
                    Count = Count + 1;
                }
               
            }
            else
            {
                Loss = Loss + 1;
                btnshot.Enabled = false;
                
            }
            if (Count >= 2)
            { // below code is for pop up the message of win and loss.
                if (Score != 0)
                {
                    MessageBox.Show("you won and your score is " + Score);
                }
                else
                {
                    MessageBox.Show("you loss and your score is " + Score);
                }
            }

           
        }

        private void russian_Load(object sender, EventArgs e)
        {
            label2.Text = roulette.name;
            Image img = Image.FromFile(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\real me.jpg");
            BackgroundImage = img;
            //below code is for hiding the image(picbox) 
            picbox.Visible = false;
            btnspin.Enabled = false;
            btnshot.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnload_Click(object sender, EventArgs e)
        {// below code helps to show the picbox
            picbox.Visible = true;
            Image img = Image.FromFile(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\load.gif");
            picbox.Image = img;
            //below code is for uploading sound affect
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\loading.wav");
            player.Play();
            // below code is helps to load only 1 bullet.
            load = 1;
            
            btnspin.Enabled = true;
            btnload.Enabled = false;
        }

        private void textloadvalue_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Below code is for exit the game.
            System.Diagnostics.Process.GetCurrentProcess().Kill();

            Application.Exit();


        }

        private void picbox_Click(object sender, EventArgs e)
        {

        }

        private void btnspin_Click(object sender, EventArgs e)
        {
            picbox.Visible = true;
            Image img = Image.FromFile(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\spinnn.gif");
            picbox.Image = img;
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\spinnn.wav");
            player.Play();
            //below code for spining the chamber and it will pick bullet randomly
            Random rnd = new Random();
            //below code helps to pick random number between 1-7.
            Spin = rnd.Next(1, 7);
           
            btnshot.Enabled = true;
            btnspin.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {// below code is for clearing all the data for opening new game.
            russian rus = new russian();
            rus.Show();
            this.Close();




            picbox.Visible = true;
            Image img = Image.FromFile(@"C:\Users\hp\source\repos\Rouelette\Rouelette\resource\try.jpg");
            picbox.Image = img;
            Count = 1;
            load = 0;
            Spin = 0;
          
            
        } 
    }
}
